import javax.swing.*;

public class Aleatorio {
    public static void main(String[] args) {
     String kaua = "Bora COD? 🔫";
     String aviso = "Você tem um convite ✉️";

        JOptionPane.showMessageDialog(null,aviso,"Aviso",JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null,kaua,"👉👈",JOptionPane.PLAIN_MESSAGE);





    }
}
