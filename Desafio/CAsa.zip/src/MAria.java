
import javax.swing.JOptionPane;

public class MAria {
    public static void main(String[] args) {
         String aviso = "Tenho algo pra te falar";

        String mensagem = "Eu te amo Maria Hélen Lima Carlos! 💖";

        JOptionPane.showMessageDialog(null, aviso, "AVISO ⚠️", JOptionPane.PLAIN_MESSAGE);

        JOptionPane.showMessageDialog(null, mensagem, "Mensagem de Amor", JOptionPane.PLAIN_MESSAGE);

    }
}